from django.db import models

# Create your models here.
class States:
    name: str
    active: str
    dead: str
    confirmed: str
    recovered: str
