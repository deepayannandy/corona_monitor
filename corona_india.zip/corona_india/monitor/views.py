from django.shortcuts import render
import time
import requests
import json
from  .models import States
# Create your views here.

def index(request):
    url = "https://corona-virus-world-and-india-data.p.rapidapi.com/api_india"
    state_det=[]
    tempdict={}

    headers = {
        'x-rapidapi-host': "corona-virus-world-and-india-data.p.rapidapi.com",
        'x-rapidapi-key': "83f25eb412msh3dad515eed599ecp1e68f7jsn243ed7d1a1c6"
    }
    response = requests.request("GET", url, headers=headers)

    data = json.loads(response.text)
    confirmed = data["total_values"]["confirmed"]
    deaths = data["total_values"]["deaths"]
    recovers = data["total_values"]["recovered"]
    active = data["total_values"]["active"]
    last_update = data["total_values"]["lastupdatedtime"]
    states = data['state_wise'].keys()
    for i in states:
        statedata = data['state_wise'][i]
        try:
            temp = {}
            confirmed_s = statedata["confirmed"]
            deaths_s = statedata["deaths"]
            recovers_s = statedata["recovered"]
            active_s = statedata["active"]

            temp["confirmed"] = confirmed_s
            temp["active"] = active_s
            temp["deaths"] = deaths_s
            temp['name'] = i
            temp["recovered"] = recovers_s

            state_det.append(temp)
        except:
            pass


    return render(request,'index.html',{'confirmed':confirmed ,'deaths':deaths,'recovers':recovers,'active':active,'last_update': last_update,'States': state_det })